import { db } from './client';
import { characters, settings } from './schema';

async function seed() {
  console.log('Seeding database…');

  // Default character placeholder
  const existing = await db.select().from(characters).limit(1);
  if (existing.length === 0) {
    await db.insert(characters).values({
      name: 'Untitled Influencer',
      personaBible: {
        age: 22,
        location: 'Dhaka, Bangladesh',
        occupation: 'University student',
        backstory: '',
        personality: '',
        speakingStyle: 'casual, friendly Bangla',
        signaturePhrases: [],
        topics: ['daily life', 'university', 'food', 'fashion'],
      },
      visualTraits: {
        face: '',
        hair: 'long black hair',
        eyes: 'brown',
        skinTone: 'warm beige',
        body: 'slim',
        signatureTraits: [],
      },
      voiceProfile: {
        engine: 'edge-tts',
        voiceId: 'bn-BD-NabanitaNeural',
        rate: 1.0,
        pitch: 0,
      },
    });
    console.log('✓ Created placeholder character');
  }

  // Default settings
  const defaults = [
    { key: 'cloudflare_account_id', value: '' },
    { key: 'cloudflare_api_token', value: '' },
    { key: 'posting_timezone', value: 'Asia/Dhaka' },
    { key: 'optimal_post_times', value: ['19:00', '21:00'] },
    { key: 'default_hashtags', value: ['#fyp', '#bangladesh', '#dhaka', '#viral'] },
  ];

  for (const s of defaults) {
    await db.insert(settings).values(s).onConflictDoNothing();
  }
  console.log('✓ Default settings seeded');
  console.log('Seed complete.');
}

seed().catch((err) => {
  console.error(err);
  process.exit(1);
});
