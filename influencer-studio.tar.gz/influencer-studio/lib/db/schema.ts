import { sqliteTable, text, integer, real } from 'drizzle-orm/sqlite-core';
import { sql } from 'drizzle-orm';

/* ============================================================
   CHARACTERS — your AI influencer personas
   ============================================================ */
export const characters = sqliteTable('characters', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  name: text('name').notNull(),
  // JSON: { age, location, occupation, backstory, personality, speakingStyle, signaturePhrases[], topics[] }
  personaBible: text('persona_bible', { mode: 'json' }).$type<Record<string, unknown>>(),
  // JSON: { face, hair, eyes, skinTone, body, signatureTraits[] }
  visualTraits: text('visual_traits', { mode: 'json' }).$type<Record<string, unknown>>(),
  // JSON: { engine: 'edge-tts'|'elevenlabs'|'custom', voiceId, sampleAudioId? }
  voiceProfile: text('voice_profile', { mode: 'json' }).$type<Record<string, unknown>>(),
  masterImageId: integer('master_image_id'),
  isActive: integer('is_active', { mode: 'boolean' }).default(true),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text('updated_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   IMAGES — character image library
   ============================================================ */
export const images = sqliteTable('images', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  characterId: integer('character_id').references(() => characters.id, { onDelete: 'cascade' }),
  filePath: text('file_path').notNull(),
  thumbnailPath: text('thumbnail_path'),
  prompt: text('prompt'),
  negativePrompt: text('negative_prompt'),
  seed: integer('seed'),
  // 'cloudflare' | 'pollinations' | 'gemini' | 'upload' | 'extracted'
  source: text('source').notNull().default('upload'),
  model: text('model'), // e.g. 'flux-1-schnell', 'sdxl'
  width: integer('width'),
  height: integer('height'),
  // JSON array: ['casual', 'cafe', 'smiling', 'kurti']
  tags: text('tags', { mode: 'json' }).$type<string[]>().default([]),
  // 1-5 manual rating
  qualityScore: integer('quality_score').default(0),
  isMaster: integer('is_master', { mode: 'boolean' }).default(false),
  isFavorite: integer('is_favorite', { mode: 'boolean' }).default(false),
  notes: text('notes'),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   AUDIO_CLIPS — generated Bangla voice samples
   ============================================================ */
export const audioClips = sqliteTable('audio_clips', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  characterId: integer('character_id').references(() => characters.id, { onDelete: 'cascade' }),
  filePath: text('file_path').notNull(),
  transcript: text('transcript').notNull(),
  language: text('language').default('bn-BD'),
  voiceEngine: text('voice_engine').notNull(), // 'edge-tts' | 'elevenlabs' | 'upload'
  voiceId: text('voice_id'), // e.g. 'bn-BD-NabanitaNeural'
  rate: real('rate').default(1.0),
  pitch: real('pitch').default(0),
  durationSec: real('duration_sec'),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   TRENDS — saved trending videos for inspiration
   ============================================================ */
export const trends = sqliteTable('trends', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  sourceUrl: text('source_url').notNull(),
  platform: text('platform'), // 'tiktok' | 'youtube' | 'instagram'
  title: text('title'),
  description: text('description'),
  thumbnailPath: text('thumbnail_path'),
  videoPath: text('video_path'), // optional local download
  creator: text('creator'),
  hashtags: text('hashtags', { mode: 'json' }).$type<string[]>().default([]),
  // 'dance' | 'talking' | 'transition' | 'audio' | 'comedy' | 'other'
  category: text('category'),
  // 'new' | 'saved' | 'in-progress' | 'recreated' | 'dead'
  status: text('status').default('new'),
  // 'fresh' | 'peaking' | 'dying'
  lifecycleFlag: text('lifecycle_flag').default('fresh'),
  viewCount: integer('view_count'),
  audioName: text('audio_name'), // the sound/song name
  notes: text('notes'),
  savedAt: text('saved_at').default(sql`CURRENT_TIMESTAMP`),
  lastCheckedAt: text('last_checked_at'),
});

/* ============================================================
   VIDEO_PROJECTS — the content calendar
   ============================================================ */
export const videoProjects = sqliteTable('video_projects', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  characterId: integer('character_id').references(() => characters.id),
  trendId: integer('trend_id').references(() => trends.id, { onDelete: 'set null' }),
  scheduledDate: text('scheduled_date'), // ISO date string
  scheduledTime: text('scheduled_time'), // 'HH:MM'
  title: text('title').notNull(),
  // 'talking' | 'dance' | 'trend' | 'storytime' | 'tutorial' | 'reaction' | 'bts'
  contentType: text('content_type').default('talking'),
  // 'idea' | 'scripted' | 'assets' | 'produced' | 'edited' | 'ready' | 'posted'
  status: text('status').default('idea'),
  hook: text('hook'), // first 2 sec script
  scriptBangla: text('script_bangla'),
  scriptEnglish: text('script_english'), // translation for reference
  caption: text('caption'),
  hashtags: text('hashtags', { mode: 'json' }).$type<string[]>().default([]),
  // JSON: { imageIds: number[], audioClipIds: number[], frameIds: number[] }
  assetRefs: text('asset_refs', { mode: 'json' }).$type<{ imageIds: number[]; audioClipIds: number[]; frameIds: number[] }>().default({ imageIds: [], audioClipIds: [], frameIds: [] }),
  finalVideoPath: text('final_video_path'),
  postedUrl: text('posted_url'),
  postedAt: text('posted_at'),
  viewCount: integer('view_count'),
  likeCount: integer('like_count'),
  commentCount: integer('comment_count'),
  shareCount: integer('share_count'),
  notes: text('notes'),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
  updatedAt: text('updated_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   PRODUCTION_TASKS — per-video checklist items
   ============================================================ */
export const productionTasks = sqliteTable('production_tasks', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  videoProjectId: integer('video_project_id').references(() => videoProjects.id, { onDelete: 'cascade' }).notNull(),
  taskName: text('task_name').notNull(),
  taskOrder: integer('task_order').default(0),
  isDone: integer('is_done', { mode: 'boolean' }).default(false),
  doneAt: text('done_at'),
  notes: text('notes'),
});

/* ============================================================
   EXTRACTED_FRAMES — frames pulled from videos
   ============================================================ */
export const extractedFrames = sqliteTable('extracted_frames', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  sourceUrl: text('source_url'),
  sourceVideoPath: text('source_video_path'),
  trendId: integer('trend_id').references(() => trends.id, { onDelete: 'cascade' }),
  framePath: text('frame_path').notNull(),
  timestampSec: real('timestamp_sec'),
  tags: text('tags', { mode: 'json' }).$type<string[]>().default([]),
  // 'pose' | 'outfit' | 'lighting' | 'composition' | 'expression'
  referenceType: text('reference_type'),
  savedToLibrary: integer('saved_to_library', { mode: 'boolean' }).default(false),
  notes: text('notes'),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   PROMPTS_LIBRARY — reusable prompts that worked
   ============================================================ */
export const prompts = sqliteTable('prompts', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  characterId: integer('character_id').references(() => characters.id, { onDelete: 'cascade' }),
  name: text('name'),
  promptText: text('prompt_text').notNull(),
  negativePrompt: text('negative_prompt'),
  category: text('category'), // 'character' | 'scene' | 'outfit' | 'style'
  seed: integer('seed'),
  resultImageId: integer('result_image_id').references(() => images.id, { onDelete: 'set null' }),
  successCount: integer('success_count').default(1),
  notes: text('notes'),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   SETTINGS — app-wide key/value store
   ============================================================ */
export const settings = sqliteTable('settings', {
  key: text('key').primaryKey(),
  value: text('value', { mode: 'json' }).$type<unknown>(),
  updatedAt: text('updated_at').default(sql`CURRENT_TIMESTAMP`),
});

/* ============================================================
   POST_QUEUE — semi-auto posting reminders
   ============================================================ */
export const postQueue = sqliteTable('post_queue', {
  id: integer('id').primaryKey({ autoIncrement: true }),
  videoProjectId: integer('video_project_id').references(() => videoProjects.id, { onDelete: 'cascade' }).notNull(),
  scheduledFor: text('scheduled_for').notNull(), // ISO datetime
  platform: text('platform').default('tiktok'),
  reminderSent: integer('reminder_sent', { mode: 'boolean' }).default(false),
  posted: integer('posted', { mode: 'boolean' }).default(false),
  createdAt: text('created_at').default(sql`CURRENT_TIMESTAMP`),
});

// Type exports
export type Character = typeof characters.$inferSelect;
export type NewCharacter = typeof characters.$inferInsert;
export type Image = typeof images.$inferSelect;
export type NewImage = typeof images.$inferInsert;
export type AudioClip = typeof audioClips.$inferSelect;
export type NewAudioClip = typeof audioClips.$inferInsert;
export type Trend = typeof trends.$inferSelect;
export type NewTrend = typeof trends.$inferInsert;
export type VideoProject = typeof videoProjects.$inferSelect;
export type NewVideoProject = typeof videoProjects.$inferInsert;
export type ProductionTask = typeof productionTasks.$inferSelect;
export type ExtractedFrame = typeof extractedFrames.$inferSelect;
export type Prompt = typeof prompts.$inferSelect;
