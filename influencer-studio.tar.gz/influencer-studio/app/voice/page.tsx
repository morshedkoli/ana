import { db } from '@/lib/db/client';
import { audioClips, characters } from '@/lib/db/schema';
import { desc, eq } from 'drizzle-orm';
import { PageHeader } from '@/components/shared/page-header';
import { VoiceLab } from './voice-lab';

export const dynamic = 'force-dynamic';

export default async function VoicePage() {
  const [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);
  const recent = await db.select().from(audioClips).orderBy(desc(audioClips.createdAt)).limit(30);

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        eyebrow="Voice"
        title="Voice lab"
        description="Generate unlimited free Bangla voice via Edge TTS."
      />
      <VoiceLab character={active} recent={recent} />
    </div>
  );
}
