import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { extractedFrames, images, characters } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const IMAGES_DIR = path.join(process.cwd(), 'storage', 'images');

export async function POST(req: NextRequest) {
  try {
    const { frameId, tags = [], referenceType } = await req.json();
    const [frame] = await db.select().from(extractedFrames).where(eq(extractedFrames.id, frameId));
    if (!frame) return NextResponse.json({ error: 'Frame not found' }, { status: 404 });

    // Copy frame to images dir
    if (!fs.existsSync(IMAGES_DIR)) fs.mkdirSync(IMAGES_DIR, { recursive: true });
    const ext = path.extname(frame.framePath) || '.jpg';
    const fileName = `${Date.now()}_frame_${crypto.randomBytes(3).toString('hex')}${ext}`;
    const newPath = path.join(IMAGES_DIR, fileName);
    fs.copyFileSync(frame.framePath, newPath);

    const [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);
    await db.insert(images).values({
      characterId: active?.id,
      filePath: newPath,
      source: 'extracted',
      tags: [...tags, referenceType].filter(Boolean) as string[],
      notes: `Extracted from ${frame.sourceUrl || 'upload'} @ ${frame.timestampSec}s`,
    });

    await db.update(extractedFrames)
      .set({ savedToLibrary: true, referenceType, tags })
      .where(eq(extractedFrames.id, frameId));

    return NextResponse.json({ ok: true, publicPath: `/storage/images/${fileName}` });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
