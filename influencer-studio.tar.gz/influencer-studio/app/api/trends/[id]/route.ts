import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { trends } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  await db.update(trends).set(body).where(eq(trends.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await db.delete(trends).where(eq(trends.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}
