import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { trends } from '@/lib/db/schema';
import { fetchVideoMeta, downloadThumbnail } from '@/lib/video/yt-dlp';
import { eq, desc } from 'drizzle-orm';

export async function GET() {
  const rows = await db.select().from(trends).orderBy(desc(trends.savedAt));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { url, category, notes } = body;
    if (!url) return NextResponse.json({ error: 'URL required' }, { status: 400 });

    let meta;
    let thumbnailPath: string | undefined;
    try {
      meta = await fetchVideoMeta(url);
      try { thumbnailPath = await downloadThumbnail(url); } catch {}
    } catch (err) {
      // Save what we can even if yt-dlp fails
      const platform = /tiktok/.test(url) ? 'tiktok' :
                       /youtube|youtu\.be/.test(url) ? 'youtube' :
                       /instagram/.test(url) ? 'instagram' : 'unknown';
      meta = { url, platform, title: '', description: '', uploader: '',
        viewCount: 0, hashtags: [], audioName: undefined, raw: {} } as Awaited<ReturnType<typeof fetchVideoMeta>>;
    }

    const [inserted] = await db.insert(trends).values({
      sourceUrl: meta.url,
      platform: meta.platform,
      title: meta.title,
      description: meta.description,
      thumbnailPath,
      creator: meta.uploader,
      hashtags: meta.hashtags,
      category: category || 'other',
      viewCount: meta.viewCount,
      audioName: meta.audioName,
      notes,
    }).returning();

    return NextResponse.json(inserted);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
