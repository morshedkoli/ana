import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { settings } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(req: NextRequest) {
  const { updates } = await req.json();
  for (const u of updates) {
    const existing = await db.select().from(settings).where(eq(settings.key, u.key));
    if (existing.length > 0) {
      await db.update(settings).set({ value: u.value, updatedAt: new Date().toISOString() }).where(eq(settings.key, u.key));
    } else {
      await db.insert(settings).values({ key: u.key, value: u.value });
    }
  }
  return NextResponse.json({ ok: true });
}
