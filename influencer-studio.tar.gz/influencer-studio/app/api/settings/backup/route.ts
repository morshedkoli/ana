import { NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import {
  characters, images, audioClips, trends, videoProjects,
  productionTasks, extractedFrames, prompts, settings,
} from '@/lib/db/schema';

export async function GET() {
  const data = {
    exportedAt: new Date().toISOString(),
    characters: await db.select().from(characters),
    images: await db.select().from(images),
    audioClips: await db.select().from(audioClips),
    trends: await db.select().from(trends),
    videoProjects: await db.select().from(videoProjects),
    productionTasks: await db.select().from(productionTasks),
    extractedFrames: await db.select().from(extractedFrames),
    prompts: await db.select().from(prompts),
    settings: await db.select().from(settings),
  };
  return new NextResponse(JSON.stringify(data, null, 2), {
    headers: {
      'Content-Type': 'application/json',
      'Content-Disposition': `attachment; filename=studio-backup-${Date.now()}.json`,
    },
  });
}
