import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { characters } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  const characterId = parseInt(id);

  await db.update(characters)
    .set({
      name: body.name,
      personaBible: body.personaBible,
      visualTraits: body.visualTraits,
      voiceProfile: body.voiceProfile,
      masterImageId: body.masterImageId,
      updatedAt: new Date().toISOString(),
    })
    .where(eq(characters.id, characterId));

  return NextResponse.json({ ok: true });
}
