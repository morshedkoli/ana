import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { images } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import fs from 'fs';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  await db.update(images).set({
    tags: body.tags,
    qualityScore: body.qualityScore,
    isFavorite: body.isFavorite,
    notes: body.notes,
  }).where(eq(images.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [img] = await db.select().from(images).where(eq(images.id, parseInt(id)));
  if (img && fs.existsSync(img.filePath)) {
    try { fs.unlinkSync(img.filePath); } catch {}
  }
  await db.delete(images).where(eq(images.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}
