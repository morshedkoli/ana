import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { images, characters } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

const IMAGES_DIR = path.join(process.cwd(), 'storage', 'images');

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get('file') as File | null;
    const tagsRaw = (formData.get('tags') as string) || '';
    const notes = (formData.get('notes') as string) || '';

    if (!file) return NextResponse.json({ error: 'No file' }, { status: 400 });

    if (!fs.existsSync(IMAGES_DIR)) fs.mkdirSync(IMAGES_DIR, { recursive: true });
    const ext = path.extname(file.name) || '.png';
    const fileName = `${Date.now()}_upload_${crypto.randomBytes(3).toString('hex')}${ext}`;
    const filePath = path.join(IMAGES_DIR, fileName);

    const buffer = Buffer.from(await file.arrayBuffer());
    fs.writeFileSync(filePath, buffer);

    const [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);

    const tags = tagsRaw.split(',').map(s => s.trim()).filter(Boolean);
    const [inserted] = await db.insert(images).values({
      characterId: active?.id,
      filePath, source: 'upload', tags, notes,
    }).returning();

    return NextResponse.json({
      id: inserted.id,
      publicPath: `/storage/images/${fileName}`,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}

export async function GET() {
  const rows = await db.select().from(images).orderBy(images.createdAt);
  return NextResponse.json(rows);
}
