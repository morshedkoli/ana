import { NextRequest, NextResponse } from 'next/server';
import { generateTts } from '@/lib/tts/edge-tts';
import { db } from '@/lib/db/client';
import { audioClips, characters } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { text, voice, rate, pitch, save = false } = body;

    if (!text || text.trim().length === 0) {
      return NextResponse.json({ error: 'Text required' }, { status: 400 });
    }

    const result = await generateTts({ text, voice, rate, pitch });

    if (save) {
      const [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);
      await db.insert(audioClips).values({
        characterId: active?.id,
        filePath: result.filePath,
        transcript: text,
        voiceEngine: 'edge-tts',
        voiceId: voice,
        rate, pitch,
        durationSec: result.durationSec,
      });
    }

    return NextResponse.json({
      publicPath: result.publicPath,
      fileName: result.fileName,
      durationSec: result.durationSec,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Unknown error';
    console.error('TTS error:', err);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
