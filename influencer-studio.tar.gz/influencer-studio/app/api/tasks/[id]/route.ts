import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { productionTasks } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  await db.update(productionTasks).set({
    isDone: body.isDone,
    doneAt: body.isDone ? new Date().toISOString() : null,
  }).where(eq(productionTasks.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}
