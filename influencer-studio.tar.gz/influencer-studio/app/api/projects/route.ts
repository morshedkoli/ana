import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { videoProjects, productionTasks, characters } from '@/lib/db/schema';
import { eq, desc } from 'drizzle-orm';

const DEFAULT_TASKS = [
  'Script written',
  'Bangla audio generated',
  'Character image selected',
  'Lip-sync video produced',
  'B-roll / dance produced',
  'Edited in CapCut',
  'Captions added (Bangla subtitles)',
  'Watermarks cropped',
  'AI disclosure label noted',
];

export async function GET() {
  const rows = await db.select().from(videoProjects).orderBy(desc(videoProjects.scheduledDate));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);

  const [inserted] = await db.insert(videoProjects).values({
    characterId: active?.id,
    title: body.title,
    contentType: body.contentType || 'talking',
    scheduledDate: body.scheduledDate,
    status: body.status || 'idea',
    trendId: body.trendId,
  }).returning();

  // Auto-create the production checklist
  for (let i = 0; i < DEFAULT_TASKS.length; i++) {
    await db.insert(productionTasks).values({
      videoProjectId: inserted.id,
      taskName: DEFAULT_TASKS[i],
      taskOrder: i,
    });
  }

  return NextResponse.json(inserted);
}
