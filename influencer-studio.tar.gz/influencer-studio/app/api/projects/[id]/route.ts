import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db/client';
import { videoProjects, productionTasks } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [project] = await db.select().from(videoProjects).where(eq(videoProjects.id, parseInt(id)));
  if (!project) return NextResponse.json({ error: 'Not found' }, { status: 404 });
  const tasks = await db.select().from(productionTasks)
    .where(eq(productionTasks.videoProjectId, project.id))
    .orderBy(productionTasks.taskOrder);
  return NextResponse.json({ project, tasks });
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const body = await req.json();
  await db.update(videoProjects).set({
    ...body,
    updatedAt: new Date().toISOString(),
  }).where(eq(videoProjects.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  await db.delete(videoProjects).where(eq(videoProjects.id, parseInt(id)));
  return NextResponse.json({ ok: true });
}
