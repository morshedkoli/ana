import { db } from '@/lib/db/client';
import { characters, prompts } from '@/lib/db/schema';
import { eq, desc } from 'drizzle-orm';
import { PageHeader } from '@/components/shared/page-header';
import { GeneratePanel } from './generate-panel';

export const dynamic = 'force-dynamic';

export default async function GeneratePage() {
  const [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);
  const recentPrompts = active
    ? await db.select().from(prompts).where(eq(prompts.characterId, active.id)).orderBy(desc(prompts.createdAt)).limit(8)
    : [];

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        eyebrow="Create"
        title="Generate image"
        description="Free generation via Cloudflare Workers AI + Pollinations fallback."
      />
      <GeneratePanel character={active} recentPrompts={recentPrompts} />
    </div>
  );
}
