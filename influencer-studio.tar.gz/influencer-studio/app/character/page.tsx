import { db } from '@/lib/db/client';
import { characters, images } from '@/lib/db/schema';
import { eq, desc } from 'drizzle-orm';
import { PageHeader } from '@/components/shared/page-header';
import { CharacterEditor } from './character-editor';
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function CharacterPage() {
  let [active] = await db.select().from(characters).where(eq(characters.isActive, true)).limit(1);
  if (!active) {
    // Fallback to first character
    const all = await db.select().from(characters).limit(1);
    active = all[0];
  }

  if (!active) {
    // Should be seeded but just in case
    redirect('/');
  }

  const imgs = await db.select()
    .from(images)
    .where(eq(images.characterId, active.id))
    .orderBy(desc(images.createdAt))
    .limit(12);

  return (
    <div className="space-y-10 animate-fade-in">
      <PageHeader
        eyebrow="Identity"
        title="Character vault"
        description="Lock who she is — persona, voice, look. Every video draws from here."
      />
      <CharacterEditor character={active} recentImages={imgs} />
    </div>
  );
}
