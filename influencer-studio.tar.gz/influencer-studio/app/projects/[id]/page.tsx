import { db } from '@/lib/db/client';
import { videoProjects, productionTasks } from '@/lib/db/schema';
import { eq } from 'drizzle-orm';
import { notFound } from 'next/navigation';
import { PageHeader } from '@/components/shared/page-header';
import { ProjectWorkspace } from './project-workspace';

export const dynamic = 'force-dynamic';

export default async function ProjectPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [project] = await db.select().from(videoProjects).where(eq(videoProjects.id, parseInt(id)));
  if (!project) notFound();
  const tasks = await db.select().from(productionTasks)
    .where(eq(productionTasks.videoProjectId, project.id))
    .orderBy(productionTasks.taskOrder);

  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        eyebrow={`${project.scheduledDate || 'Unscheduled'} · ${project.contentType}`}
        title={project.title}
      />
      <ProjectWorkspace project={project} tasks={tasks} />
    </div>
  );
}
