import { db } from '@/lib/db/client';
import { trends } from '@/lib/db/schema';
import { desc } from 'drizzle-orm';
import { PageHeader } from '@/components/shared/page-header';
import { TrendsBoard } from './trends-board';

export const dynamic = 'force-dynamic';

export default async function TrendsPage() {
  const rows = await db.select().from(trends).orderBy(desc(trends.savedAt));
  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        eyebrow="Inspiration"
        title="Trend tracker"
        description="Paste TikTok / YouTube / Reels URLs to save trends with auto-fetched metadata."
      />
      <TrendsBoard trends={rows} />
    </div>
  );
}
