import { db } from '@/lib/db/client';
import { videoProjects } from '@/lib/db/schema';
import { desc } from 'drizzle-orm';
import { PageHeader } from '@/components/shared/page-header';
import { CalendarView } from './calendar-view';

export const dynamic = 'force-dynamic';

export default async function CalendarPage() {
  const projects = await db.select().from(videoProjects).orderBy(desc(videoProjects.scheduledDate));
  return (
    <div className="space-y-8 animate-fade-in">
      <PageHeader
        eyebrow="Plan"
        title="Content calendar"
        description="Map your videos across days. Drag, drop, post."
      />
      <CalendarView projects={projects} />
    </div>
  );
}
